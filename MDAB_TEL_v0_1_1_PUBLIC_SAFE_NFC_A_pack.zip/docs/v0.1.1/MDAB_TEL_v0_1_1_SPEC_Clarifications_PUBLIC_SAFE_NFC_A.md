# MDAB‑TEL — v0.1.1 Clarification Pack (PUBLIC‑SAFE)
**Purpose:** tighten determinism, hash scope clarity, and fail‑closed semantics without changing v0.1.0 artifacts.

> This document is intended as a drop‑in **normative addendum** you can copy into your spec (or use as `SPEC_ADDENDUM_v0_1_1.md`).
> It contains **MUST / MUST NOT** rules and is intentionally minimal.

---

## 1. Canonical JSON Input Requirements

### 1.1 Encoding
1. Inputs MUST be valid UTF‑8.
2. Inputs MUST NOT contain invalid Unicode scalar values (e.g., unpaired surrogates). If detected, the verifier MUST FAIL‑CLOSED.

### 1.2 JSON parsing
1. Inputs MUST be valid JSON per RFC 8259.
2. Object member names MUST be unique. Duplicate keys MUST trigger FAIL‑CLOSED (no “last‑wins” semantics).
3. Numbers MUST be handled as specified in Section 2.3 (restricted numeric domain). Any deviation MUST FAIL‑CLOSED.
4. Any parse ambiguity MUST trigger FAIL‑CLOSED.

---

## 2. Canonicalization Determinism

### 2.1 Deterministic serialization
Canonicalization MUST be deterministic across platforms, runtimes, and language implementations.

### 2.2 Strings (Unicode normalization policy — NFC inside)

To prevent cross‑implementation drift from visually‑equivalent Unicode strings:

1. Prior to canonical serialization, **all JSON strings MUST be normalized to Unicode NFC**.
2. If NFC normalization cannot be performed due to invalid Unicode scalar values, the verifier MUST FAIL‑CLOSED.
3. After NFC normalization, serialization MUST proceed deterministically.

### 2.3 Numbers (restricted domain)
To prevent cross‑implementation drift, the numeric domain is restricted as follows:

1. Only **signed integers** are permitted.
2. Integers MUST be represented without leading zeros (except the literal `0`).
3. Floating point numbers are forbidden (`1.0`, `1e3`, `-0.0`), as are NaN/Infinity representations (even if a parser accepts them).
4. `-0` MUST FAIL‑CLOSED.
5. If a value cannot be represented as an integer in the chosen domain, the verifier MUST FAIL‑CLOSED.

*(If you need broader numeric support later, define a v0.2 numeric profile; do not widen v0.1.x.)*

### 2.4 Unknown members / forward compatibility (v0.1.x)
To prevent equivocation and “shadow semantics”:

- Any JSON object member not explicitly defined by the schema MUST cause FAIL‑CLOSED.

*(Forward‑compat should be introduced only via an explicit, namespaced extension container in a future version.)*

---

## 3. Hash Scope — explicit and non‑ambiguous

### 3.1 Scope MUST include (domain separation)
The hash scope MUST include, at minimum:

1. `spec_version` (or equivalent version identifier)
2. `schema_id` / `event_type` (domain separation between object types)
3. canonical payload bytes (the output of canonicalization)
4. hash algorithm identifier (e.g., `sha256`)
5. `prev_hash` (for chained records; omit only for genesis where explicitly defined)

### 3.2 Scope MUST exclude
The scope MUST NOT include:

- filesystem paths, build paths, runtime environment strings
- timestamps that are not part of the logical payload
- comments, whitespace, or transport metadata
- the signature bytes themselves (avoid circular dependence)

### 3.3 Equivocation test
If any two records differ in `schema_id/event_type` or canonical payload, their scope hash MUST differ.

---

## 4. Chain Semantics (if hash‑chain is used)

1. Each non‑genesis record MUST include `prev_hash` equal to the scope hash of the immediately prior record.
2. Verifiers MUST validate chain continuity (no gaps, no reorder).
3. Any missing link, mismatch, or truncation MUST FAIL‑CLOSED.

---

## 5. Signature Semantics (if signatures are used)

1. The signature MUST authenticate **the scope hash** (recommended) or the canonical payload bytes; choose ONE and specify it.
2. Signature verification metadata (key id, algorithm id) MUST be defined as verification inputs.
3. The signature bytes MUST NOT be included in the bytes being signed (no circularity).
4. Any signature mismatch MUST FAIL‑CLOSED.

---

## 6. Reproducibility contract (documentation level)

1. Repro steps MUST be ≤ 5 commands/steps.
2. Expected outputs MUST include at least:
   - PASS/FAIL outcome
   - resulting scope hash (or digest)
   - tool/version identifier used for the run
3. Any mismatch in expected outputs MUST STOP the workflow (FAIL‑CLOSED).

---
