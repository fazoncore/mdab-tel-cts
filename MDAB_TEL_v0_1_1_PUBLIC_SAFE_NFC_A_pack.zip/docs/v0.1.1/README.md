# MDAB‑TEL v0.1.1 — Public‑Safe Clarification Pack (NFC_A)

This folder contains:
- Spec clarifications (determinism hardening):
  - Unicode: normalize all strings to NFC prior to canonical serialization
  - Unknown fields: FAIL‑CLOSED in v0.1.x
  - Numbers: strict FAIL‑CLOSED for float/scientific/-0/etc.
  - Duplicate keys: FAIL‑CLOSED
  - Hash scope + chain semantics: explicit

- Fixtures manifest (what to add under fixtures/v0.1.1/)
- Expected outputs template (fill AFTER running CTS/verifier)
- Release notes template (copy into GitHub Release for v0.1.1)

NOTE: v0.1.1 is clarifications + fixtures only. v0.1.0 remains immutable.
